import AWS from 'aws-sdk';
import express from 'express';

const app = express();
app.use(express.json())

AWS.config.update({
    region: "us-east-1", // North virginia - USA
});

let index = 0;

const table = "anuncios"

const db = new AWS.DynamoDB.DocumentClient();

app.get('/api/anuncios', (req, res) => {

    const params = {
        TableName: table,
    };

    db.scan(params, (err, { Items }) => {
        if (err) {
            console.error("Error al recuperar los anuncios: ", JSON.stringify(err, null, 2));
        } else {
            res.send(Items);
        }
    });

});

app.post('/api/anuncios', ({ body }, res) => {

    const anuncio = body;
    anuncio.id = index;

    const params = {
        TableName: table,
        Item: anuncio
    };

    db.put(params, (err, data) => {
        if (err) {
            console.error("Error al procesar el JSON:", JSON.stringify(err, null, 2));
            res.send(err);
        } else {
            console.log("Anuncio creado");
            index++;
            res.send("Anuncio creado");
        }
    });

});

app.listen(3000, () => {
    console.log('Anuncios app listening on port 3000!');
});